
from src.vista import window

def main():
    window.mainloop()

if __name__ == "__main__":
    main()